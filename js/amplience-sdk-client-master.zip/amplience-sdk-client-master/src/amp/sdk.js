/**
 * amp amplience-sdk-client v{{VERSION}}
 *
 * @class amp
 */
var amp = amp || {};

(function(){

    amp.di = {};
    amp.stats = {};
    /* test-code */
    amp.test = {};
    /* end-test-code */

//import "sdk-polyfill.js"
//import "sdk-init.js"
//import "sdk-shared-methods.js"
//import "sdk-get.js"
//import "sdk-content.js"
//import "sdk-gen-html.js"
//import "sdk-di.js"
//import "sdk-analytics.js"

}());